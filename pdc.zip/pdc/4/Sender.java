import javax.jms.*;
import org.apache.activemq.ActiveMQConnectionFactory;

public class Sender implements Runnable {
    public void run() {
        // ActiveMQ Connection Setup
        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:61616");
        try {
            Connection connection = connectionFactory.createConnection();
            connection.start();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topic = session.createTopic("MyTopic");  // Define a topic
            MessageProducer producer = session.createProducer(topic);
            
            // Create and send a text message
            TextMessage message = session.createTextMessage("Hello, Subscribers!");
            producer.send(message);
            
            System.out.println("Message sent: " + message.getText());
            
            producer.close();
            session.close();
            connection.close();
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}
