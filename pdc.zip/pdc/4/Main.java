public class Main {
    public static void main(String[] args) {
        // Instantiate sender and subscriber
        Runnable sender = new Sender();
        Runnable subscriber = new Subscriber();
        
        // Create threads
        Thread t1 = new Thread(sender);
        Thread t2 = new Thread(subscriber);
        
        // Start the threads
        t1.start();
        t2.start();
        
        try {
            t1.join();
            t2.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
