import javax.jms.*;
import org.apache.activemq.ActiveMQConnectionFactory;

public class Subscriber implements Runnable {
    public void run() {
        // ActiveMQ Connection Setup
        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:61616");
        try {
            Connection connection = connectionFactory.createConnection();
            connection.start();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topic = session.createTopic("MyTopic");  // Subscribe to the same topic
            MessageConsumer consumer = session.createConsumer(topic);
            
            // Set the message listener
            consumer.setMessageListener(new MessageListener() {
                @Override
                public void onMessage(Message message) {
                    if (message instanceof TextMessage) {
                        try {
                            TextMessage textMessage = (TextMessage) message;
                            System.out.println("Received message: " + textMessage.getText());
                        } catch (JMSException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            
            System.out.println("Waiting for messages...");
            // Sleep for a while to allow message consumption
            Thread.sleep(10000);
            
            consumer.close();
            session.close();
            connection.close();
        } catch (JMSException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
