import java.rmi.Remote;
import java.rmi.RemoteException;

public interface StringReversal extends Remote {
    // Method to check if str1 is the reverse of str2
    String isReverse(String str1, String str2) throws RemoteException;
}
