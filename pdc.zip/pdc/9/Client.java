import java.rmi.Naming;

public class Client {
    public static void main(String[] args) {
        try {
            // Lookup the remote object from the RMI registry
            StringReversal reversalService = (StringReversal) Naming.lookup("rmi://localhost/StringReversalService");

            // Define two strings
            String str1 = "dlrow";
            String str2 = "world";

            // Call the remote method
            String result = reversalService.isReverse(str1, str2);

            // Print the result
            System.out.println(result);
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
