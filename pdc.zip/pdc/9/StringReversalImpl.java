import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class StringReversalImpl extends UnicastRemoteObject implements StringReversal {
    
    // Constructor that throws RemoteException
    protected StringReversalImpl() throws RemoteException {
        super();
    }

    // Implementation of the isReverse method
    @Override
    public String isReverse(String str1, String str2) throws RemoteException {
        String reversedStr2 = new StringBuilder(str2).reverse().toString();
        
        if (str1.equals(reversedStr2)) {
            return "\"" + str1 + "\" is the reverse of \"" + str2 + "\".";
        } else {
            return "\"" + str1 + "\" is NOT the reverse of \"" + str2 + "\".";
        }
    }
}
