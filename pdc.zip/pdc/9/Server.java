import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.Naming;

public class Server {
    public static void main(String[] args) {
        try {
            // Start the RMI registry on port 1099
            Registry registry = LocateRegistry.createRegistry(1099);

            // Create an instance of the implementation class
            StringReversalImpl reversalService = new StringReversalImpl();

            // Bind the remote object in the registry
            Naming.rebind("rmi://localhost/StringReversalService", reversalService);

            System.out.println("Server is running...");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
