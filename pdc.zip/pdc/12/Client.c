// #include <stdio.h>
// #include <stdlib.h>
// #include <mpi.h>
// #include <stdbool.h>  // Include this header for the 'bool' type

// int main(int argc, char** argv) {
//     int rank, size;
//     int number = 29;  // Example number to check if it is prime
//     bool result;      // Declare 'result' as a boolean

//     // Initialize MPI
//     MPI_Init(&argc, &argv);

//     // Get the rank and size of the processes
//     MPI_Comm_rank(MPI_COMM_WORLD, &rank);
//     MPI_Comm_size(MPI_COMM_WORLD, &size);

//     if (rank == 1) {
//         // Client process: Sends integer to server (rank 0)
//         MPI_Send(&number, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);

//         // Receive the result (whether it's prime or not) from the server
//         MPI_Recv(&result, 1, MPI_C_BOOL, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

//         // Print the result
//         if (result) {
//             printf("The number %d is a prime number.\n", number);
//         } else {
//             printf("The number %d is NOT a prime number.\n", number);
//         }
//     }

//     // Finalize MPI
//     MPI_Finalize();
//     return 0;
// }


// #include <stdio.h>
// #include <stdlib.h>
// #include <mpi.h>
// #include <stdbool.h>

// int main(int argc, char** argv) {
//     int rank, size;
//     int number = 29;  // Example number to check if it is prime
//     bool result;

//     // Initialize MPI
//     MPI_Init(&argc, &argv);

//     // Get the rank and size of the processes
//     MPI_Comm_rank(MPI_COMM_WORLD, &rank);
//     MPI_Comm_size(MPI_COMM_WORLD, &size);

//     if (rank == 1) {
//         // Client process: Sends integer to server (rank 0)
//         printf("Client sending number: %d\n", number);  // Debugging line
//         MPI_Send(&number, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);

//         // Receive the result (whether it's prime or not) from the server
//         MPI_Recv(&result, 1, MPI_C_BOOL, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
//         printf("Client received result: %d\n", result);  // Debugging line

//         // Print the result
//         if (result) {
//             printf("The number %d is a prime number.\n", number);
//         } else {
//             printf("The number %d is NOT a prime number.\n", number);
//         }
//     }

//     // Finalize MPI
//     MPI_Finalize();
//     return 0;
// }


#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char** argv) {
    int rank, number = 29, result;  // Using a sample number (29) for prime check
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);  // Get the rank of the process

    if (rank == 1) {  // Client logic
        // Client sends the number to the server
        printf("Client sending number: %d\n", number);
        MPI_Send(&number, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);

        // Client receives the result from the server
        MPI_Recv(&result, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
        // Client prints the result from the server
        if (result == 1) {
            printf("The number %d is prime.\n", number);
        } else {
            printf("The number %d is not prime.\n", number);
        }
    }

    MPI_Finalize();
    return 0;
}

