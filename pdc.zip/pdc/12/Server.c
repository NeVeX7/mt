// #include <stdio.h>
// #include <stdlib.h>
// #include <mpi.h>
// #include <stdbool.h>

// // Function to check if a number is prime
// bool is_prime(int num) {
//     if (num <= 1) return false;
//     for (int i = 2; i * i <= num; i++) {
//         if (num % i == 0) {
//             return false;
//         }
//     }
//     return true;
// }

// int main(int argc, char** argv) {
//     int rank, size;
//     int number;
//     bool result;

//     // Initialize MPI
//     MPI_Init(&argc, &argv);
    
//     // Get the rank and size of the processes
//     MPI_Comm_rank(MPI_COMM_WORLD, &rank);
//     MPI_Comm_size(MPI_COMM_WORLD, &size);

//     if (rank == 0) {
//         // Server process: Receives integer from client and checks if it is prime
//         MPI_Status status;

//         // Wait to receive the number from client (rank 1)
//         MPI_Recv(&number, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, &status);

//         // Check if the number is prime
//         result = is_prime(number);

//         // Send the result back to the client
//         MPI_Send(&result, 1, MPI_C_BOOL, 1, 1, MPI_COMM_WORLD);
//     }

//     // Finalize MPI
//     MPI_Finalize();
//     return 0;
// }


// #include <stdio.h>
// #include <stdlib.h>
// #include <mpi.h>
// #include <stdbool.h>

// // Function to check if a number is prime
// bool is_prime(int num) {
//     if (num <= 1) return false;
//     for (int i = 2; i * i <= num; i++) {
//         if (num % i == 0) {
//             return false;
//         }
//     }
//     return true;
// }

// int main(int argc, char** argv) {
//     int rank, size;
//     int number;
//     bool result;

//     // Initialize MPI
//     MPI_Init(&argc, &argv);

//     // Get the rank and size of the processes
//     MPI_Comm_rank(MPI_COMM_WORLD, &rank);
//     MPI_Comm_size(MPI_COMM_WORLD, &size);

//     if (rank == 0) {
//         // Server process: Receives integer from client and checks if it is prime
//         MPI_Status status;

//         // Wait to receive the number from client (rank 1)
//         MPI_Recv(&number, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, &status);
//         printf("Server received the number: %d\n", number);  // Debugging line

//         // Check if the number is prime
//         result = is_prime(number);

//         // Send the result back to the client
//         MPI_Send(&result, 1, MPI_C_BOOL, 1, 1, MPI_COMM_WORLD);
//         printf("Server sending result: %d\n", result);  // Debugging line
//     }

//     // Finalize MPI
//     MPI_Finalize();
//     return 0;
// }


#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char** argv) {
    int rank, number, result;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);  // Get the rank of the process

    if (rank == 0) {  // Server logic
        // Server is receiving a number from the client
        MPI_Recv(&number, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Server received the number: %d\n", number);

        // Simple check if the number is prime (for testing purposes)
        result = (number % 2 == 0) ? 0 : 1;  // Example prime check: 0 if not prime, 1 if prime
        // Sending back the result to the client
        MPI_Send(&result, 1, MPI_INT, 1, 1, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
}

