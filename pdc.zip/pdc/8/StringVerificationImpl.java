import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class StringVerificationImpl extends UnicastRemoteObject implements StringVerification {
    
    // Constructor that throws RemoteException
    protected StringVerificationImpl() throws RemoteException {
        super();
    }

    // Implementation of the isSubstring method
    @Override
    public String isSubstring(String str1, String str2) throws RemoteException {
        if (str2.contains(str1)) {
            return "\"" + str1 + "\" is a substring of \"" + str2 + "\".";
        } else {
            return "\"" + str1 + "\" is NOT a substring of \"" + str2 + "\".";
        }
    }
}
