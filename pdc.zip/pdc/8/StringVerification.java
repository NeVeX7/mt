import java.rmi.Remote;
import java.rmi.RemoteException;

public interface StringVerification extends Remote {
    // Method to check if str1 is a substring of str2
    String isSubstring(String str1, String str2) throws RemoteException;
}
