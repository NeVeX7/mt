import java.rmi.Naming;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            // Get the string comparison service from the RMI registry
            StringComparison stub = (StringComparison) Naming.lookup("rmi://localhost/StringComparisonService");

            Scanner scanner = new Scanner(System.in);

            // Prompt the user to enter two strings
            System.out.print("Enter the first string: ");
            String str1 = scanner.nextLine();
            System.out.print("Enter the second string: ");
            String str2 = scanner.nextLine();

            // Invoke the remote method to compare the vowels
            boolean result = stub.compareVowels(str1, str2);

            // Print the result
            if (result) {
                System.out.println("Both strings have the same number of vowels.");
            } else {
                System.out.println("The strings do not have the same number of vowels.");
            }

            scanner.close();
        } catch (Exception e) {
            System.out.println("Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
