
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface StringComparison extends Remote {
    // Method to compare the number of vowels in both strings
    boolean compareVowels(String str1, String str2) throws RemoteException;
}
