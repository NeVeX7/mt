import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class StringComparisonImpl extends UnicastRemoteObject implements StringComparison {
    public StringComparisonImpl() throws RemoteException {
        super();
    }

    @Override
    public boolean compareVowels(String str1, String str2) throws RemoteException {
        int vowelsCount1 = countVowels(str1);
        int vowelsCount2 = countVowels(str2);

        // Compare if both strings have the same number of vowels
        return vowelsCount1 == vowelsCount2;
    }

    // Helper method to count vowels in a string
    private int countVowels(String str) {
        int count = 0;
        String vowels = "AEIOUaeiou";

        for (char c : str.toCharArray()) {
            if (vowels.indexOf(c) != -1) {
                count++;
            }
        }
        return count;
    }
}
