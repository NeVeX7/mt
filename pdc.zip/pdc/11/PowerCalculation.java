
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PowerCalculation extends Remote {
    // Method to calculate a raised to the power of b
    double calculatePower(int a, int b) throws RemoteException;
}