import java.rmi.Naming;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            // Get the PowerCalculation service from the RMI registry
            PowerCalculation stub = (PowerCalculation) Naming.lookup("rmi://localhost/PowerCalculationService");

            Scanner scanner = new Scanner(System.in);

            // Prompt the user to enter two integers
            System.out.print("Enter the base integer (a): ");
            int a = scanner.nextInt();
            System.out.print("Enter the exponent integer (b): ");
            int b = scanner.nextInt();

            // Invoke the remote method to calculate a raised to the power of b
            double result = stub.calculatePower(a, b);

            // Print the result
            System.out.println("Result: " + a + " raised to the power of " + b + " is " + result);

            scanner.close();
        } catch (Exception e) {
            System.out.println("Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
