import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class PowerCalculationImpl extends UnicastRemoteObject implements PowerCalculation {

    public PowerCalculationImpl() throws RemoteException {
        super();
    }

    @Override
    public double calculatePower(int a, int b) throws RemoteException {
        // Calculate a raised to the power of b
        return Math.pow(a, b);
    }
}
