import java.rmi.*;
import java.rmi.server.*;

public class MyRemoteObject extends UnicastRemoteObject implements MyRemoteInterface {
    public MyRemoteObject() throws RemoteException {
        super();
    }

    public String sayHello(String name) throws RemoteException {
        return "Hello, " + name;
    }

    public static void main(String[] args) {
        try {
            // Create and export the remote object
            MyRemoteObject remoteObject = new MyRemoteObject();
            Naming.rebind("HelloService", remoteObject);
            System.out.println("Server is ready!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
