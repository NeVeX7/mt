import java.rmi.*;

public interface MyRemoteInterface extends Remote {
    String sayHello(String name) throws RemoteException;
}
