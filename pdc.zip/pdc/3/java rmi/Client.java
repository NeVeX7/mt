import java.rmi.*;

public class Client {
    public static void main(String[] args) {
        try {
            // Look up the remote object in the RMI registry
            MyRemoteInterface remoteObject = (MyRemoteInterface) Naming.lookup("rmi://localhost/HelloService");
            
            // Call the remote method
            String response = remoteObject.sayHello("World");
            System.out.println(response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
