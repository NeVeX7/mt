import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            // Create client socket and connect to server
            Socket socket = new Socket("localhost", 1234);

            // Input and Output streams for communication
            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            // Send message to server
            out.writeUTF("Hello from the client!");

            // Read the response from the server
            String response = in.readUTF();
            System.out.println("Received from server: " + response);

            // Close the streams and socket
            in.close();
            out.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
