import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class StringConcatenationImpl extends UnicastRemoteObject implements StringConcatenation {
    
    // Constructor that throws RemoteException
    protected StringConcatenationImpl() throws RemoteException {
        super();
    }

    // Implementation of the concatenate method
    @Override
    public String concatenate(String str1, String str2) throws RemoteException {
        return str1 + str2;
    }
}
