import java.rmi.Naming;

public class Client {
    public static void main(String[] args) {
        try {
            // Lookup the remote object
            StringConcatenation concatService = (StringConcatenation) Naming.lookup("rmi://localhost/StringConcatenationService");

            // Define two strings to concatenate
            String str1 = "Hello, ";
            String str2 = "world!";

            // Call the remote method
            String result = concatService.concatenate(str1, str2);

            // Print the result
            System.out.println("Concatenated result: " + result);
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
